from django.contrib import admin
from main_app.models import Book

admin.site.register(Book)
